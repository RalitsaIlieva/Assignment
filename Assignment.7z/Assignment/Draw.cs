﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    public class Draw
    {
  
        private static void FirstRow(int x)
        {
            string dash = "";
          string star = "";
          string dash2 = "";
            for (int i = 0; i < x; i++)
            {
               dash += "-";
                star += "*";
                dash2 += "-";
            }
            Console.Write(dash + star + dash2 + star + dash + dash + star + dash2 + star + dash);
            Console.WriteLine();
        }   
        private static void FirstHalf(int x)
        {
            string dash = "";
            string star = "";
            string dash2 = "";
            for (int i = 0; i < x; i++)
            {
                dash += "-";
                star += "*";
                dash2 += "-";
            }
            for (int k = 0; k < x / 2; k++)
            {
                dash2 = dash2.Substring(0, dash2.Length - 2);
                dash = dash.Substring(0, dash.Length - 1);
                star = star + "**";

                for (int i = 0; i < x * 10; i++)
                {
                    Console.Write(dash + star + dash2 + star + dash);

                    i += x * 5;

                }
                Console.WriteLine();
            }
        }
        private static void SecondHalf(int x)
        {
            string dash = "";
            string dash2 = "";
            for (int i = 0; i < x; i++)
            {
                dash += "-";
                dash2 += "-";
            }
            for (int k = 0; k < x / 2; k++)
            {
                dash2 = dash2.Substring(0, dash2.Length - 2);
                dash = dash.Substring(0, dash.Length - 1);
            }

            string star = "";
            string star2 = "";
            for (int i = 0; i < x; i++)
            {
                star += "*";
            }

            dash = dash.Substring(0, dash.Length - 1);
            for (int i = 0; i < x + (x - 1); i++)
            {
                star2 += "*";
            }


            for (int k = 0; k < x / 2; k++)
            {

                for (int i = 0; i < x * 10; i++)
                {

                    Console.Write(dash + star + dash2 + star2 + dash2 + star + dash);

                    i += x * 5;

                }
                Console.WriteLine();
                dash2 = dash2 + "--";
                dash = dash.Substring(0, dash.Length - 1);
                star2 = star2.Substring(0, star2.Length - 2);
            }
        }
        private static void LastRow(int x)
        {
            string dash2 = "";
            for (int i = 0; i < x; i++)
            {
                dash2 += "-";
            }
            for (int k = 0; k < x / 2; k++)
            {
                dash2 = dash2.Substring(0, dash2.Length - 2);
            }
            string star = "";
            for (int i = 0; i < x; i++)
            {
                star += "*";
            }

            for (int k = 0; k < x / 2; k++)
            {
                dash2 = dash2 + "--";
            }
            Console.Write(star + dash2 + star + dash2 + star + star + dash2 + star + dash2 + star);
        }
        public void Print() {
            int number = Int32.Parse(Console.ReadLine());
            Check(number);
            FirstRow(number);
            FirstHalf(number);
            SecondHalf(number);
            LastRow(number);
        }
        private static void Check(int x) {
            if (x <= 2 || x >= 10000)
            {
                throw new ArgumentOutOfRangeException();
            }
            if (x % 2 == 0) {
                throw new ArgumentException();
            }
        
        }
    }
}


